


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pallavisingh
 */
import java.io.IOException;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet(name="change_pwd",urlPatterns={"/change_pwd"})
public class change_pwd extends HttpServlet {
            protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                
                    Statement stmt=null;
Connection cn=null;
                HttpSession session = request.getSession();
                  
                
                     String sid=(String)request.getParameter("sid");
                     System.out.println("-------      "+sid);
String currentPassword=request.getParameter("current");
String Newpass=request.getParameter("new");
String conpass=request.getParameter("confirm");
System.out.println(currentPassword);
String pass="";
try{
     Class.forName("com.mysql.jdbc.Driver");
                String str="jdbc:mysql://localhost:3306/Finance_Mgmt";
             cn=DriverManager.getConnection(str,"root","");
stmt=cn.createStatement();

    String chashPass =HashPassword.generateHash(currentPassword);
    String newPass=HashPassword.generateHash(Newpass);
ResultSet rs=stmt.executeQuery("select * from seller_profile where seller_id='"+sid+"'");
if(rs.next()){
     pass=rs.getString("Password");
} System.out.println( " "+pass);
if(pass.equals(chashPass)){
Statement st1=cn.createStatement();
int i=st1.executeUpdate("update seller_profile set Password='"+newPass+"' where seller_id='"+sid+"'");
System.out.println("Password changed successfully");
 RequestDispatcher rd = request.getRequestDispatcher("seller_home.jsp");
            rd.include(request, response);
session.setAttribute("pwd","valid") ;
st1.close();
cn.close();
}
else{
    session.setAttribute("pwd","invalid") ;
System.out.println("Invalid Current Password"+sid);
 RequestDispatcher rd = request.getRequestDispatcher("seller_home.jsp");
            rd.include(request, response);
}
}
catch(Exception e){
System.out.println(e);
}
                }
    
            }



import java.sql.Connection;
import java.sql.Statement;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(name="RegisterSeller",urlPatterns={"/RegisterSeller"})
public class RegisterSeller extends HttpServlet {
        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            Statement stmt;
            ResultSet rs,res1;
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
            rd.include(request, response);
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                String str="jdbc:mysql://localhost:3306/Finance_Mgmt";
            Connection con=DriverManager.getConnection(str,"root","");
            stmt = (java.sql.Statement)con.createStatement();
            String fname=request.getParameter("fname");
            String lname=request.getParameter("lname");
            String email=request.getParameter("email");
            String hno=request.getParameter("hno");
            String area=request.getParameter("area");
            String city=request.getParameter("city");
            String country=request.getParameter("country");
            String pcode=request.getParameter("pcode");
            String phone=request.getParameter("phone");
            String company=request.getParameter("company");
            String website=request.getParameter("site");
            String state=request.getParameter("state");
            System.out.println("ghgjgjhgj");
            String pass=request.getParameter("pass");
            System.out.println(pass);
            
            String hashPass = HashPassword.generateHash(pass);
            System.out.println(hashPass);
            String sql="INSERT INTO `seller_profile`(`FName`, `LName`, `Email`, `Password`, `H.No.`, `Area/Locality`,`State`, `City`, `Country`, `Pin-code`, `Phone No.`, `Company`, `Website`) VALUES ('"+fname+"','"+lname+"','"+email+"','"+hashPass+"','"+hno+"','"+area+"','"+state+"','"+city+"','"+country+"','"+pcode+"','"+phone+"','"+company+"','"+website+"')";
            System.out.println(sql);
            stmt.executeUpdate(sql);
            System.out.println("hhhhhhhhh");
            }
            catch(Exception e)
            {
                System.out.println(e);
            }
            }
}

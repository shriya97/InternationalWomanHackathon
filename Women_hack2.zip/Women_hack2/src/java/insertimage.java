
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
 
@WebServlet("/insertimage")
public class insertimage extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    try
    {
        String sid=(String)req.getSession().getAttribute("sid");
        String pdt_name=req.getParameter("pname");
    String pdt_des=req.getParameter("pdis");
    String cprice=req.getParameter("cprice");
    String sprice=req.getParameter("sprice");
    String qty=req.getParameter("qty");
       // RequestDispatcher rd = req.getRequestDispatcher("check.jsp");
         //   rd.include(req, res);
        Class.forName("com.mysql.jdbc.Driver");
                String str="jdbc:mysql://localhost:3306/Finance_Mgmt";
             Connection cn=DriverManager.getConnection(str,"root","");
Statement stmt=cn.createStatement();
    String ImageFile="";
    String itemName = "";
    boolean isMultipart = ServletFileUpload.isMultipartContent(req);
    System.out.println("hihihi");
    if (!isMultipart)
    {
        System.out.println("hihihi33333");
    }
    else
    {
        System.out.println("hihihi4444444");
    FileItemFactory factory = new DiskFileItemFactory();
    System.out.println("hihihi77");
    ServletFileUpload upload = new ServletFileUpload(factory);
    List items = null;
    
        System.out.println("hihihi55");
    items = (List) upload.parseRequest(req);
    
    
    System.out.println("hihihi66");
    Iterator itr = items.iterator();
    while (itr.hasNext())
    {
    FileItem item = (FileItem) itr.next();
    if (item.isFormField())
    {
    String name = item.getFieldName();
    String value = item.getString();
    if(name.equals("ImageFile"))
    {
    ImageFile=value;
    }
    if(name.equals("pdis"))
    {pdt_des=value;
    System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@"+value);
    }
    if(name.equals("pname"))
    {
        pdt_name=value;
    System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@omg"+value+" "+pdt_name);
    }
    if(name.equals("cprice"))
    {
        cprice=value;
    System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@omg"+value+" "+cprice);
    }
    if(name.equals("sprice"))
    {
        sprice=value;
    System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@omg"+value+" "+sprice);
    }
    if(name.equals("qty"))
    {
        qty=value;
    System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@omg"+value+" "+qty);
    }
    }
    else
    {
    
    itemName = item.getName();
    System.out.println("hihihi11111");
    ServletContext context = req.getServletContext();
    String path = context.getRealPath("/");
    InputStream input = context.getResourceAsStream("/index.jsp");
    File savedFile = new File(path+"/images/"+itemName);
    item.write(savedFile);
    
    }
    }
    
    System.out.println(pdt_name);
    System.out.println("hihihi222222");
    String s="select * from seller_pdt where pdt_name='"+pdt_name+"' and pdt_description='"+pdt_des+"'";
    System.out.println(s);
    ResultSet rs=stmt.executeQuery(s);
    if(rs.next())
    {
        String available_qty=rs.getString("available_qty");
        String qty_purchased=rs.getString("qty_purchased");
        String p=rs.getString("cprice");
        String p1=rs.getString("sprice");
        String sp=rs.getString("total_selling_cost");
        int avail=Integer.parseInt(available_qty);
        int qy=Integer.parseInt(qty);
        int pr=Integer.parseInt(p);
        int pr1=Integer.parseInt(p1);
        int qp=Integer.parseInt(qty_purchased);
        int sell=pr1*qp;
        int add=avail+qy;
        stmt.executeUpdate("UPDATE `seller_pdt` SET `pdt_name`='"+pdt_name+"',`pdt_description`='"+pdt_des+"',`cprice`='"+cprice+"',`sprice`='"+sprice+"',`available_qty`='"+add+"',`qty_purchased`='"+qty_purchased+"',`total_selling_cost`='"+sell+"',`Image`='"+itemName+"' WHERE seller_id='"+sid+"' and pdt_name='"+pdt_name+"' and pdt_description='"+pdt_des+"' ");

    }
    else
    stmt.executeUpdate("insert into seller_pdt(seller_id,pdt_name,pdt_description,cprice,sprice,available_qty,Image) values ('"+sid+"','"+pdt_name+"','"+pdt_des+"','"+cprice+"','"+sprice+"','"+qty+"','"+itemName+"')");

    String message = "response added successfully";
req.getSession().setAttribute("message", message);
res.sendRedirect("seller_home.jsp");
    }
    }
    catch (Exception e){
    System.out.println(e.getMessage());
    }
    }
}

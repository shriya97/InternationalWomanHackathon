
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet(name="loggingProcess",urlPatterns={"/loggingProcess"})
public class loggingProcess extends HttpServlet{
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email,passwd;
        System.out.println("Invalidkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkfdfdfdfdfdf user");
        HttpSession session = request.getSession();
        System.out.println("kkk");
        email=request.getParameter("Email");
        passwd=request.getParameter("Pwd");
try{
    System.out.println("kkk6666");
    Statement stmt=null,stmt1=null,stmt2=null;
Connection cn=null;
System.out.println("kkk00000");
    Class.forName("com.mysql.jdbc.Driver");
                String str="jdbc:mysql://localhost:3306/Finance_Mgmt";
             cn=DriverManager.getConnection(str,"root","");
             System.out.println("kkk3333");
stmt=cn.createStatement();
stmt1=cn.createStatement();
stmt2=cn.createStatement();
ResultSet rs1,rs2,rs3;
String str1,str2,str3;
System.out.println("kkk``````");
System.out.println(email+"*************************************");
String hashPass = HashPassword.generateHash(passwd);
str1="select * from seller_profile where Email='"+email+"' AND Password='"+hashPass+"'";
str2="select * from ngo_profile where Email='"+email+"' AND Password='"+hashPass+"'";
str3="select * from buyer_profile where Email='"+email+"' AND Password='"+hashPass+"'";
System.out.println("kkk111");
rs1=stmt.executeQuery(str1);
System.out.println("kkkeee");
rs2=stmt1.executeQuery(str2);
System.out.println("kkkggg");
rs3=stmt2 .executeQuery(str3);
System.out.println(str3);
System.out.println("Invalidkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk user"+passwd);
RequestDispatcher rq1,rq2,rq3;
        session.setAttribute("email",email);
if(rs1.next()){
  String useremail=rs1.getString("Email");
  System.out.println("Invalidmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm user");
  String sid=rs1.getString("seller_id");
  session.setAttribute("person","seller");
  session.setAttribute("sid",sid);
  rq1=request.getRequestDispatcher("seller_home.jsp");
  rq1.include(request, response);
}
else if(rs2.next()){
  String useremail=rs2.getString("Email"); 
  System.out.println("Invalid pppppppppppppppppppppppppppppppppppppppppppuser");
  String ngoid=rs2.getString("ngo_id");
   session.setAttribute("person","ngo");
   session.setAttribute("ngoid",ngoid);
  rq2=request.getRequestDispatcher("NgoPage.jsp");
  rq2.include(request, response);
}
else if(rs3.next()){
    System.out.println("Invalidhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh user");
  String useremail=rs3.getString("Email"); 
  String bid=rs3.getString("buyer_id");
   session.setAttribute("person","buyer");
   session.setAttribute("bid",bid);
  rq3=request.getRequestDispatcher("buyerHome1.jsp");
  rq3.include(request, response);
}
else{
    System.out.println("Invalid user");
    rq3=request.getRequestDispatcher("index.jsp");
  rq3.include(request, response);
}


}catch(Exception e){
System.out.println("kkk"+e);
}
            
        }
}

/* ------------------------------------ Click on login and Sign Up to  changue and view the effect
---------------------------------------
*/

 
function cambiar_login() {
  document.querySelector('.cont_forms').className = "cont_forms cont_forms_active_login";  
document.querySelector('.cont_form_login').style.display = "block";
document.querySelector('.cont_form_sign_up').style.opacity = "0";               

setTimeout(function(){  document.querySelector('.cont_form_login').style.opacity = "1"; },400);  
  
setTimeout(function(){    
document.querySelector('.cont_form_sign_up').style.display = "none";
},200);  
  }

var check = function() {
  if (document.getElementById('pass').value ==
    document.getElementById('cpass').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'matching';
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'not matching';
  }
}


//---------------------------------
function cambiar_sign_up(at) {
  document.querySelector('.cont_forms').className = "cont_forms cont_forms_active_sign_up";
  document.querySelector('.cont_form_sign_up').style.display = "block";

document.querySelector('.cont_form_login').style.opacity = "0";
  
setTimeout(function(){  document.querySelector('.cont_form_sign_up').style.opacity = "1";
},100);  

setTimeout(function(){   document.querySelector('.cont_form_login').style.display = "none";
},400);  


}    
var xmlHttp;
function register_seller(type)
{
                if(typeof  XMLHttpRequest !== "undefined"){
                    xmlHttp = new XMLHttpRequest();
                }
                else if(window.ActiveXObject){
                    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                
                if(xmlHttp === null){
                    alert("Browser does not support XMLHTTP Request");
                    return;
                }
                
                var url = "register_seller.jsp";
                url+="?type="+type;
                
                xmlHttp.onreadystatechange = stateChange1;
                xmlHttp.open("GET", url, true);
                xmlHttp.send(null);
                
}
 function stateChange1(){   
                if (xmlHttp.readyState===4 || xmlHttp.readyState==="complete"){ 
                 document.getElementById("buyer").style.display="none";
                document.getElementById("ngo").style.display="none";   
                document.getElementById("seller").innerHTML=xmlHttp.responseText   ;
                }   
            } 
   
function register_buyer(type)
{
                if(typeof  XMLHttpRequest !== "undefined"){
                    xmlHttp = new XMLHttpRequest();
                }
                else if(window.ActiveXObject){
                    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                
                if(xmlHttp === null){
                    alert("Browser does not support XMLHTTP Request");
                    return;
                }
                
                var url = "register_buyer.jsp";
                
                
                xmlHttp.onreadystatechange = stateChange2;
                xmlHttp.open("GET", url, true);
                xmlHttp.send(null);
                
}

 function stateChange2(){   
                if (xmlHttp.readyState===4 || xmlHttp.readyState==="complete"){ 
                document.getElementById("seller").style.display="none";
                document.getElementById("ngo").style.display="none";
                document.getElementById("buyer").innerHTML=xmlHttp.responseText   ;
                }   
            } 
 function register_ngo(type)
{
                if(typeof  XMLHttpRequest !== "undefined"){
                    xmlHttp = new XMLHttpRequest();
                }
                else if(window.ActiveXObject){
                    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                
                if(xmlHttp === null){
                    alert("Browser does not support XMLHTTP Request");
                    return;
                }
                
                var url = "register_ngo.jsp";
              
                
                xmlHttp.onreadystatechange = stateChange3;
                xmlHttp.open("GET", url, true);
                xmlHttp.send(null);
                
}
function stateChange3(){   
                if (xmlHttp.readyState===4 || xmlHttp.readyState==="complete"){ 
                document.getElementById("seller").style.display="none";
                document.getElementById("buyer").style.display="none";    
                document.getElementById("ngo").innerHTML=xmlHttp.responseText   ;
                }   
            } 
 
function ocultar_login_sign_up() {

document.querySelector('.cont_forms').className = "cont_forms";  
document.querySelector('.cont_form_sign_up').style.opacity = "0";               
document.querySelector('.cont_form_login').style.opacity = "0"; 

setTimeout(function(){
document.querySelector('.cont_form_sign_up').style.display = "none";
document.querySelector('.cont_form_login').style.display = "none";

},500);  
  
  }